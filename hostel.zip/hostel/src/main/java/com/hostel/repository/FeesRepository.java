package com.hostel.repository;

import com.hostel.model.Fees;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FeesRepository extends JpaRepository<Fees, Long> {
    List<Fees> findByStudentId(Long studentId);
}
