package com.hostel.controller;

import com.hostel.model.Fees;
import com.hostel.repository.FeesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fees")
public class FeesController {

    @Autowired
    private FeesRepository feesRepository;

    @GetMapping
    public List<Fees> getAllFees() {
        return feesRepository.findAll();
    }

    @GetMapping("/student/{studentId}")
    public List<Fees> getFeesByStudent(@PathVariable Long studentId) {
        return feesRepository.findByStudentId(studentId);
    }

    @PostMapping
    public Fees addFees(@RequestBody Fees fees) {
        return feesRepository.save(fees);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Fees> updateFees(@PathVariable Long id, @RequestBody Fees feesDetails) {
        return feesRepository.findById(id).map(fees -> {
            fees.setAmount(feesDetails.getAmount());
            fees.setStatus(feesDetails.getStatus());
            fees.setDate(feesDetails.getDate());
            return ResponseEntity.ok(feesRepository.save(fees));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteFees(@PathVariable Long id) {
        return feesRepository.findById(id).map(fees -> {
            feesRepository.delete(fees);
            return ResponseEntity.ok().build();
        }).orElse(ResponseEntity.notFound().build());
    }
}
