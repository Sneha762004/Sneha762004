package com.hostel.controller;

import com.hostel.model.Student;
import com.hostel.model.Room;
import com.hostel.repository.StudentRepository;
import com.hostel.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private RoomRepository roomRepository;

    @GetMapping
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
        return studentRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> createStudent(@RequestBody Student student) {
        if (student.getRoom() != null && student.getRoom().getId() != null) {
            Room room = roomRepository.findById(student.getRoom().getId()).orElse(null);
            if (room == null) {
                room = roomRepository.findByRoomNumber(student.getRoom().getId().toString()).orElse(null);
            }

            if (room != null) {
                if (room.getCurrentOccupancy() >= room.getCapacity()) {
                    return ResponseEntity.status(400).body("{\"message\": \"Error: Room " + room.getRoomNumber() + " is already full.\"}");
                }
                room.setCurrentOccupancy(room.getCurrentOccupancy() + 1);
                roomRepository.save(room);
                student.setRoom(room);
            } else {
                return ResponseEntity.status(404).body("{\"message\": \"Error: Room not found.\"}");
            }
        }
        return ResponseEntity.ok(studentRepository.save(student));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateStudent(@PathVariable Long id, @RequestBody Student studentDetails) {
        return studentRepository.findById(id).map(student -> {
            if (studentDetails.getName() != null) student.setName(studentDetails.getName());
            if (studentDetails.getEmail() != null) student.setEmail(studentDetails.getEmail());
            if (studentDetails.getPhone() != null) student.setPhone(studentDetails.getPhone());
            if (studentDetails.getPassword() != null && !studentDetails.getPassword().isEmpty()) {
                 student.setPassword(studentDetails.getPassword());
            }
            
            // Handle Room Assignment
            if (studentDetails.getRoom() != null && studentDetails.getRoom().getId() != null) {
                Long newRoomId = studentDetails.getRoom().getId();
                Room oldRoom = student.getRoom();
                
                // If the room is actually changing
                if (oldRoom == null || !oldRoom.getId().equals(newRoomId)) {
                    Room newRoom = roomRepository.findById(newRoomId).orElse(null);
                    if (newRoom == null) {
                        // Fallback: Try finding by Room Number (as a string)
                        newRoom = roomRepository.findByRoomNumber(newRoomId.toString()).orElse(null);
                    }
                    
                    if (newRoom == null) {
                        return ResponseEntity.status(404).body("{\"message\": \"Error: Room ID or Number '" + newRoomId + "' not found.\"}");
                    }
                    
                    if (newRoom.getCurrentOccupancy() >= newRoom.getCapacity()) {
                        return ResponseEntity.status(400).body("{\"message\": \"Error: Room " + newRoom.getRoomNumber() + " is already full.\"}");
                    }
                    
                    // Decrement old room occupancy
                    if (oldRoom != null) {
                        oldRoom.setCurrentOccupancy(Math.max(0, oldRoom.getCurrentOccupancy() - 1));
                        roomRepository.save(oldRoom);
                    }
                    
                    // Increment new room occupancy
                    newRoom.setCurrentOccupancy(newRoom.getCurrentOccupancy() + 1);
                    roomRepository.save(newRoom);
                    
                    student.setRoom(newRoom);
                }
            }

            Student updatedStudent = studentRepository.save(student);
            return ResponseEntity.ok(updatedStudent);
        }).orElse(ResponseEntity.status(404).body("{\"message\": \"Error: Student not found.\"}"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteStudent(@PathVariable Long id) {
        return studentRepository.findById(id).map(student -> {
            Room room = student.getRoom();
            if (room != null) {
                room.setCurrentOccupancy(Math.max(0, room.getCurrentOccupancy() - 1));
                roomRepository.save(room);
            }
            studentRepository.delete(student);
            return ResponseEntity.ok().build();
        }).orElse(ResponseEntity.notFound().build());
    }
}
