package com.hostel.controller;

import com.hostel.model.Admin;
import com.hostel.model.Student;
import com.hostel.repository.AdminRepository;
import com.hostel.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private StudentRepository studentRepository;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        String username = credentials.get("username");
        String password = credentials.get("password");
        String role = credentials.get("role");

        Map<String, Object> response = new HashMap<>();

        if ("ADMIN".equalsIgnoreCase(role)) {
            Admin admin = adminRepository.findByUsername(username);
            if (admin != null && admin.getPassword().equals(password)) {
                response.put("success", true);
                response.put("role", "ADMIN");
                response.put("userId", admin.getId());
                return ResponseEntity.ok(response);
            }
        } else if ("STUDENT".equalsIgnoreCase(role)) {
            Student student = studentRepository.findByEmail(username);
            if (student == null) {
                try {
                    Long studentId = Long.parseLong(username);
                    student = studentRepository.findById(studentId).orElse(null);
                } catch (NumberFormatException e) {
                    // Ignore, will fall through to invalid credentials
                }
            }
            if (student != null && student.getPassword().equals(password)) {
                response.put("success", true);
                response.put("role", "STUDENT");
                response.put("userId", student.getId());
                return ResponseEntity.ok(response);
            }
        }

        response.put("success", false);
        response.put("message", "Invalid credentials");
        return ResponseEntity.status(401).body(response);
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Student student) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (studentRepository.findByEmail(student.getEmail()) != null) {
                response.put("success", false);
                response.put("message", "Email already exists");
                return ResponseEntity.badRequest().body(response);
            }
            studentRepository.save(student);
            response.put("success", true);
            response.put("message", "Registration successful! Your Student ID is: " + student.getId());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("success", false);
            response.put("message", "Registration failed: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }
}
