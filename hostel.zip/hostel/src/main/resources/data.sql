-- Add Initial Admin
INSERT IGNORE INTO admin (id, username, password, email) VALUES (1, 'admin', 'admin123', 'admin@hostel.com');

-- Add Initial Students
INSERT IGNORE INTO student (name, email, phone, password) VALUES ('Sneha', 'sneha@example.com', '9876543210', 'sneha123');
INSERT IGNORE INTO student (name, email, phone, password) VALUES ('Rahul', 'rahul@example.com', '8876543210', 'rahul123');
INSERT IGNORE INTO student (name, email, phone, password) VALUES ('Priya', 'priya@example.com', '7876543210', 'priya123');

-- Add Initial Rooms
INSERT IGNORE INTO room (room_number, type, capacity, current_occupancy) VALUES ('101', 'AC', 2, 0);
INSERT IGNORE INTO room (room_number, type, capacity, current_occupancy) VALUES ('102', 'Non-AC', 3, 0);
