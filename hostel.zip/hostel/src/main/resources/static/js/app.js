// app.js - Logic for Hostel Management System
alert('System Logic Loaded!');

document.addEventListener('DOMContentLoaded', () => {
    // Login Logic
    const loginForm = document.getElementById('loginForm');
    const roleSelect = document.getElementById('role');
    const studentIdGroup = document.getElementById('studentIdGroup');
    const adminUsernameGroup = document.getElementById('adminUsernameGroup');
    const studentIdInput = document.getElementById('studentIdInput');
    const adminUsernameInput = document.getElementById('adminUsernameInput');

    if (roleSelect) {
        roleSelect.addEventListener('change', () => {
            if (roleSelect.value === 'STUDENT') {
                studentIdGroup.style.display = 'block';
                adminUsernameGroup.style.display = 'none';
                studentIdInput.required = true;
                adminUsernameInput.required = false;
            } else {
                studentIdGroup.style.display = 'none';
                adminUsernameGroup.style.display = 'block';
                studentIdInput.required = false;
                adminUsernameInput.required = true;
            }
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const role = document.getElementById('role').value;
            const password = document.getElementById('password').value;
            let username = '';
            
            if (role === 'STUDENT') {
                username = document.getElementById('studentIdInput').value;
            } else {
                username = document.getElementById('adminUsernameInput').value;
            }
            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ role, username, password })
                });
                
                const data = await response.json().catch(() => ({ success: false, message: 'Server error' }));
                
                if (response.ok && data.success) {
                    localStorage.setItem('userRole', data.role);
                    localStorage.setItem('userId', data.userId);
                    console.log('Login success:', data);
                    
                    if (data.role === 'ADMIN') {
                        window.location.href = 'admin-dashboard.html';
                    } else {
                        window.location.href = 'student-dashboard.html';
                    }
                } else {
                    console.error('Login failed:', data);
                    alert('Login Failed: ' + (data.message || 'Check your credentials and role'));
                    document.getElementById('loginError').innerText = data.message || 'Invalid credentials';
                    document.getElementById('loginError').style.display = 'block';
                }
            } catch (error) {
                console.error('Login connection error:', error);
                alert('Server connection failed. Is your Spring Boot app running?');
                document.getElementById('loginError').innerText = 'Server connection failed';
                document.getElementById('loginError').style.display = 'block';
            }
        });
    }

    // Registration Logic
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            alert('Step 1: Form Submitted');
            
            const name = document.getElementById('regName').value;
            const email = document.getElementById('regEmail').value;
            const phone = document.getElementById('regPhone').value;
            const password = document.getElementById('regPassword').value;
            
            const msgDiv = document.getElementById('regMessage');
            msgDiv.innerText = 'Processing...';
            msgDiv.style.display = 'block';
            
            try {
                alert('Step 2: Sending data to server...');
                const response = await fetch('/api/auth/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, email, phone, password })
                });
                
                alert('Step 3: Server responded with status ' + response.status);
                const data = await response.json();
                
                if (response.ok && data.success) {
                    alert('Step 4: Registration SUCCESS!\n' + data.message);
                    msgDiv.innerText = '✅ ' + data.message + ' Redirecting in 5s...';
                    msgDiv.style.color = 'var(--success)';
                    setTimeout(() => window.location.href = 'index.html', 5000);
                } else {
                    alert('Step 4: Registration FAILED: ' + (data.message || 'Unknown error'));
                    msgDiv.innerText = '❌ ' + (data.message || 'Registration failed');
                    msgDiv.style.color = 'var(--danger)';
                }
            } catch (error) {
                alert('Step 2 ERROR: ' + error.message);
                console.error('Reg error:', error);
                msgDiv.innerText = '❌ Error: ' + error.message;
            }
        });
    }

    // Logout Logic
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            localStorage.removeItem('userRole');
            localStorage.removeItem('userId');
            window.location.href = 'index.html';
        });
    }

    // Modal logic helper
    window.openModal = (modalId) => {
        document.getElementById(modalId).classList.add('active');
    };
    window.closeModal = (modalId) => {
        document.getElementById(modalId).classList.remove('active');
    };

    window.openAssignRoom = async (studentId) => {
        const input = document.getElementById('assignStudId');
        if(input) input.value = studentId;
        
        const roomSelect = document.getElementById('assignRoomId');
        if (roomSelect) {
            roomSelect.innerHTML = '<option value="">-- Loading Rooms... --</option>';
            const rooms = await apiFetch('/api/rooms', { silent: true });
            if (rooms) {
                roomSelect.innerHTML = '<option value="">-- Select a Room --</option>';
                rooms.forEach(room => {
                    const status = room.currentOccupancy >= room.capacity ? '(Full)' : '';
                    const option = document.createElement('option');
                    option.value = room.id;
                    option.innerText = `Room ${room.roomNumber} - ${room.type} (${room.currentOccupancy}/${room.capacity}) ${status}`;
                    if (room.currentOccupancy >= room.capacity) option.disabled = true;
                    roomSelect.appendChild(option);
                });
            } else {
                roomSelect.innerHTML = '<option value="">Error loading rooms</option>';
            }
        }
        
        window.openModal('assignRoomModal');
    };

    // Load dynamic data if on admin dashboard
    if (window.location.pathname.includes('admin-dashboard')) {
        checkAuth('ADMIN');
        loadAdminData();
    }
    // Load dynamic data if on student dashboard
    if (window.location.pathname.includes('student-dashboard')) {
        checkAuth('STUDENT');
        loadStudentData();
    }
});

function checkAuth(requiredRole) {
    const role = localStorage.getItem('userRole');
    const userId = localStorage.getItem('userId');
    if (role !== requiredRole || !userId) {
        console.warn('Auth check failed. Redirecting to login.');
        window.location.href = 'index.html';
    }
}

// Fetch helper
async function apiFetch(url, options = {}) {
    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            let errorMessage = `Server error: ${response.status}`;
            try {
                const errorData = await response.json();
                errorMessage = errorData.message || errorMessage;
            } catch (e) { /* ignore parse error */ }
            
            throw new Error(errorMessage);
        }
        if(options.method === 'DELETE') return true;
        return await response.json();
    } catch (err) {
        console.error(`Fetch error for ${url}:`, err);
        // Only alert if it's not a background fetch or if explicitly needed
        if (!options.silent) {
            alert('Request Failed: ' + err.message);
        }
        return null;
    }
}

// --- Admin Functions ---
async function loadAdminData() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const tab = link.dataset.tab;
            if (!tab) return;
            
            document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.style.display = 'none');
            
            link.classList.add('active');
            const content = document.getElementById(`content-${tab}`);
            if (content) content.style.display = 'block';
            
            fetchTabData(tab);
        });
    });

    fetchTabData('students');

    // Add Student Form
    const addStudentForm = document.getElementById('addStudentForm');
    if (addStudentForm) {
        addStudentForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const studentData = {
                name: document.getElementById('addStudName').value,
                email: document.getElementById('addStudEmail').value,
                phone: document.getElementById('addStudPhone').value,
                password: document.getElementById('addStudPassword').value
            };
            const result = await apiFetch('/api/students', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(studentData)
            });
            if (result) {
                closeModal('studentModal');
                addStudentForm.reset();
                fetchTabData('students');
            }
        });
    }

    // Add Room Form
    const addRoomForm = document.getElementById('addRoomForm');
    if (addRoomForm) {
        addRoomForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const roomData = {
                roomNumber: document.getElementById('addRoomNum').value,
                type: document.getElementById('addRoomType').value,
                capacity: parseInt(document.getElementById('addRoomCap').value),
                currentOccupancy: 0
            };
            const result = await apiFetch('/api/rooms', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(roomData)
            });
            if (result) {
                closeModal('roomModal');
                addRoomForm.reset();
                fetchTabData('rooms');
            }
        });
    }

    // Add Fees Form
    const addFeesForm = document.getElementById('addFeesForm');
    if (addFeesForm) {
        addFeesForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const feeData = {
                student: { id: parseInt(document.getElementById('feeStudId').value) },
                amount: parseFloat(document.getElementById('feeAmount').value),
                status: document.getElementById('feeStatus').value,
                date: document.getElementById('feeDate').value
            };
            const result = await apiFetch('/api/fees', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(feeData)
            });
            if (result) {
                alert('Fee recorded successfully!');
                closeModal('feesModal');
                addFeesForm.reset();
                fetchTabData('fees');
            }
        });
    }

    // Add Attendance Form
    const addAttendanceForm = document.getElementById('addAttendanceForm');
    if (addAttendanceForm) {
        addAttendanceForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const attData = {
                student: { id: parseInt(document.getElementById('attStudId').value) },
                status: document.getElementById('attStatus').value,
                date: document.getElementById('attDate').value
            };
            const result = await apiFetch('/api/attendance', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(attData)
            });
            if (result) {
                closeModal('attendanceModal');
                addAttendanceForm.reset();
                fetchTabData('attendance');
            }
        });
    }

    // Add Visitor Form
    const addVisitorForm = document.getElementById('addVisitorForm');
    if (addVisitorForm) {
        addVisitorForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const visData = {
                visitorName: document.getElementById('visName').value,
                studentId: parseInt(document.getElementById('visStudId').value),
                date: document.getElementById('visDate').value,
                inTime: document.getElementById('visInTime').value,
                outTime: document.getElementById('visOutTime').value
            };
            const result = await apiFetch('/api/visitors', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(visData)
            });
            if (result) {
                closeModal('visitorModal');
                addVisitorForm.reset();
                fetchTabData('visitors');
            }
        });
    }

    // Assign Room Form
    const assignRoomForm = document.getElementById('assignRoomForm');
    if (assignRoomForm) {
        assignRoomForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const studentId = document.getElementById('assignStudId').value;
            const roomId = document.getElementById('assignRoomId').value;
            const updateData = {
                room: { id: parseInt(roomId) }
            };
            const result = await apiFetch(`/api/students/${studentId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updateData)
            });
            if (result) {
                closeModal('assignRoomModal');
                assignRoomForm.reset();
                fetchTabData('students');
                fetchTabData('rooms');
            }
        });
    }
}

async function fetchTabData(tab) {
    const tbody = document.getElementById(`tbody-${tab}`);
    if(!tbody) return;
    tbody.innerHTML = '<tr><td colspan="6">Loading...</td></tr>';
    const data = await apiFetch(`/api/${tab}`);
    if(data) renderTable(tab, data, tbody);
    else tbody.innerHTML = '<tr><td colspan="6">Error loading data</td></tr>';
}

function renderTable(tab, data, tbody) {
    tbody.innerHTML = '';
    if(data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6">No data available</td></tr>';
        return;
    }
    data.forEach(item => {
        const tr = document.createElement('tr');
        if(tab === 'students') {
            tr.innerHTML = `<td>${item.id}</td><td>${item.name}</td><td>${item.email}</td><td>${item.phone}</td><td>${item.room ? item.room.roomNumber : 'None'}</td>
            <td>
                <button class="btn" style="padding: 0.25rem 0.5rem; margin-right: 0.5rem;" onclick="openAssignRoom(${item.id})">Assign Room</button>
                <button class="btn btn-danger" style="padding: 0.25rem 0.5rem;" onclick="deleteItem('students', ${item.id})">Delete</button>
            </td>`;
        } else if (tab === 'rooms') {
            tr.innerHTML = `<td>${item.id}</td><td>${item.roomNumber}</td><td>${item.type}</td><td>${item.capacity}</td><td>${item.currentOccupancy}</td><td><button class="btn btn-danger" onclick="deleteItem('rooms', ${item.id})">Delete</button></td>`;
        } else if (tab === 'fees') {
            tr.innerHTML = `<td>${item.student ? item.student.id : 'N/A'}</td><td>${item.amount}</td><td>${item.status}</td><td>${item.date}</td><td><button class="btn btn-danger" onclick="deleteItem('fees', ${item.id})">Delete</button></td>`;
        } else if (tab === 'attendance') {
            tr.innerHTML = `<td>${item.student ? item.student.id : 'N/A'}</td><td>${item.date}</td><td>${item.status}</td><td><button class="btn btn-danger" onclick="deleteItem('attendance', ${item.id})">Delete</button></td>`;
        } else if (tab === 'complaints') {
            tr.innerHTML = `
                <td>${item.student ? item.student.id : 'N/A'}</td>
                <td>${item.description}</td>
                <td><span style="color: ${item.status === 'Resolved' ? 'var(--success)' : 'var(--danger)'}">${item.status}</span></td>
                <td>
                    ${item.status === 'Pending' ? `<button class="btn" style="padding: 0.25rem 0.5rem; margin-right: 0.5rem; background: var(--success);" onclick="resolveComplaint(${item.id})">Resolve</button>` : ''}
                    <button class="btn btn-danger" style="padding: 0.25rem 0.5rem;" onclick="deleteItem('complaints', ${item.id})">Delete</button>
                </td>
            `;
        } else if (tab === 'visitors') {
            tr.innerHTML = `<td>${item.visitorName}</td><td>${item.studentId}</td><td>${item.date}</td><td>${item.inTime}</td><td>${item.outTime || '-'}</td><td><button class="btn btn-danger" onclick="deleteItem('visitors', ${item.id})">Delete</button></td>`;
        }
        tbody.appendChild(tr);
    });
}

window.resolveComplaint = async (id) => {
    const success = await apiFetch(`/api/complaints/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'Resolved' })
    });
    if(success) fetchTabData('complaints');
};

window.deleteItem = async (tab, id) => {
    if(confirm('Are you sure you want to delete this?')) {
        const success = await apiFetch(`/api/${tab}/${id}`, { method: 'DELETE' });
        if(success) {
            fetchTabData(tab);
            if (tab === 'students') fetchTabData('rooms');
        }
    }
};

// --- Student Functions ---
async function loadStudentData() {
    const studentId = localStorage.getItem('userId');
    if (!studentId) {
        console.error('No Student ID found in local storage.');
        return;
    }

    console.log('Loading data for student:', studentId);
    const student = await apiFetch(`/api/students/${studentId}`);
    
    if(student) {
        document.getElementById('studentName').innerText = student.name;
        
        const idElem = document.getElementById('profileStudentId');
        if(idElem) idElem.innerText = student.id;
        
        const roomElem = document.getElementById('profileStudentRoom');
        const roomNo = student.room ? student.room.roomNumber : 'Not Assigned Yet';
        if(roomElem) {
            roomElem.innerText = roomNo;
            const helpText = document.getElementById('roomHelpText');
            if (roomNo === 'Not Assigned Yet') {
                roomElem.style.color = 'var(--text-muted)';
                if(helpText) helpText.style.display = 'block';
            } else {
                roomElem.style.color = 'var(--primary-color)';
                if(helpText) helpText.style.display = 'none';
            }
        }

        // Update Header Profile Info
        const headerId = document.getElementById('headerStudentId');
        if(headerId) headerId.innerText = student.id;
        const headerRoom = document.getElementById('headerStudentRoom');
        if(headerRoom) headerRoom.innerText = roomNo;
    } else {
        alert('Could not load your profile. Please try logging in again.');
    }
    
    const fees = await apiFetch(`/api/fees/student/${studentId}`);
    if (fees) {
        const pending = fees.filter(f => f.status === 'Pending');
        const totalPending = pending.reduce((sum, f) => sum + f.amount, 0);
        
        const feeElem = document.getElementById('profileStudentFees');
        const headerFeeElem = document.getElementById('headerStudentFees');
        
        const displayFeeText = totalPending > 0 ? `₹${totalPending}` : '0';
        const displayFeeColor = totalPending > 0 ? 'var(--danger)' : 'var(--success)';

        if(feeElem) {
            feeElem.innerText = totalPending > 0 ? `₹${totalPending}` : 'No Pending Fees';
            feeElem.style.color = displayFeeColor;
        }

        if(headerFeeElem) {
            headerFeeElem.innerText = displayFeeText;
            headerFeeElem.style.color = displayFeeColor;
        }
    }

    const tabs = ['profile', 'complaints'];
    tabs.forEach(tab => {
        const link = document.getElementById(`nav-${tab}`);
        if(link) {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.style.display = 'none');
                link.classList.add('active');
                document.getElementById(`content-${tab}`).style.display = 'block';
            });
        }
    });

    // Student Complaint Logic
    const studentComplaintForm = document.getElementById('studentComplaintForm');
    if (studentComplaintForm) {
        studentComplaintForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const msgDiv = document.getElementById('studentCompMsg');
            const compData = {
                student: { id: parseInt(studentId) },
                description: document.getElementById('complaintDesc').value,
                status: 'Pending'
            };

            const result = await apiFetch('/api/complaints', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(compData)
            });

            if (result) {
                msgDiv.innerText = 'Complaint submitted successfully! Admin will review it soon.';
                msgDiv.style.color = 'var(--success)';
                msgDiv.style.display = 'block';
                studentComplaintForm.reset();
                setTimeout(() => msgDiv.style.display = 'none', 5000);
            }
        });
    }
}
