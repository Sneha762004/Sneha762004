package com.medreminder.medreminder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedreminderApplicationTests {

	@Test
	void contextLoads() {
	}

}
