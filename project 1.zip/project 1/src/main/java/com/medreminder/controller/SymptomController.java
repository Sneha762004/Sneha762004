package com.medreminder.controller;

import com.medreminder.model.SymptomLog;
import com.medreminder.model.User;
import com.medreminder.repository.SymptomLogRepository;
import com.medreminder.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/symptoms")
public class SymptomController {

    @Autowired
    private SymptomLogRepository symptomRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/{userId}")
    public ResponseEntity<?> addSymptom(@PathVariable Long userId, @RequestBody SymptomLog log) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isEmpty()) return ResponseEntity.badRequest().body("User not found");

        log.setUser(userOpt.get());
        log.setDate(LocalDate.now()); // automatically log for today
        return ResponseEntity.ok(symptomRepository.save(log));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<SymptomLog>> getUserSymptoms(@PathVariable Long userId) {
        return ResponseEntity.ok(symptomRepository.findByUserId(userId));
    }
}
