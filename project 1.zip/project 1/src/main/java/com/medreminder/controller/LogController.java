package com.medreminder.controller;

import com.medreminder.model.Medicine;
import com.medreminder.model.MedicineLog;
import com.medreminder.repository.MedicineLogRepository;
import com.medreminder.repository.MedicineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/logs")
public class LogController {

    @Autowired
    private MedicineLogRepository logRepository;
    
    @Autowired
    private MedicineRepository medicineRepository;

    @PostMapping("/{medicineId}/mark")
    public ResponseEntity<?> markLog(@PathVariable Long medicineId, @RequestParam MedicineLog.Status status) {
        Optional<Medicine> medOpt = medicineRepository.findById(medicineId);
        if (medOpt.isEmpty()) return ResponseEntity.badRequest().body("Medicine not found");
        
        LocalDate today = LocalDate.now();
        Optional<MedicineLog> existingLog = logRepository.findByMedicineIdAndDate(medicineId, today);
        
        MedicineLog log = existingLog.orElse(new MedicineLog());
        log.setMedicine(medOpt.get());
        log.setDate(today);
        log.setStatus(status);
        
        return ResponseEntity.ok(logRepository.save(log));
    }

    @GetMapping("/medicine/{medicineId}")
    public ResponseEntity<List<MedicineLog>> getLogs(@PathVariable Long medicineId) {
        return ResponseEntity.ok(logRepository.findByMedicineId(medicineId));
    }
}
