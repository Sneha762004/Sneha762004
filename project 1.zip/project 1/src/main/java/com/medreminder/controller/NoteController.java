package com.medreminder.controller;

import com.medreminder.model.DoctorNote;
import com.medreminder.model.User;
import com.medreminder.repository.DoctorNoteRepository;
import com.medreminder.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/notes")
public class NoteController {

    @Autowired
    private DoctorNoteRepository noteRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/user/{userId}")
    public ResponseEntity<?> addNote(@PathVariable Long userId, @RequestBody DoctorNote note) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isEmpty()) return ResponseEntity.badRequest().body("Patient not found");

        note.setUser(userOpt.get());
        return ResponseEntity.ok(noteRepository.save(note));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<DoctorNote>> getNotes(@PathVariable Long userId) {
        return ResponseEntity.ok(noteRepository.findByUserId(userId));
    }
}
