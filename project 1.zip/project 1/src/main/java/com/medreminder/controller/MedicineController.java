package com.medreminder.controller;

import com.medreminder.model.Medicine;
import com.medreminder.model.User;
import com.medreminder.repository.MedicineRepository;
import com.medreminder.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/medicines")
public class MedicineController {

    @Autowired
    private MedicineRepository medicineRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/{userId}")
    public ResponseEntity<?> addMedicine(@PathVariable Long userId, @RequestBody Medicine medicine) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isEmpty()) return ResponseEntity.badRequest().body("User not found");
        
        // --- CONFLICT DETECTION LOGIC ---
        List<Medicine> existingMeds = medicineRepository.findByUserId(userId);
        for (Medicine existing : existingMeds) {
            // Check if times match exactly and dates overlap
            if (existing.getTime().equals(medicine.getTime())) {
                if (!medicine.getEndDate().isBefore(existing.getStartDate()) && !medicine.getStartDate().isAfter(existing.getEndDate())) {
                    return ResponseEntity.badRequest().body("CONFLICT: Another medicine (" + existing.getName() + ") is already scheduled at exactly " + existing.getTime() + ". Please choose a slightly different time to avoid taking them together!");
                }
            }
        }
        
        medicine.setUser(userOpt.get());
        Medicine savedMedicine = medicineRepository.save(medicine);
        return ResponseEntity.ok(savedMedicine);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Medicine>> getUserMedicines(@PathVariable Long userId) {
        return ResponseEntity.ok(medicineRepository.findByUserId(userId));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteMedicine(@PathVariable Long id) {
        medicineRepository.deleteById(id);
        return ResponseEntity.ok("Deleted successfully");
    }
}
