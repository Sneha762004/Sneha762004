package com.medreminder.controller;

import com.medreminder.model.MedicineLog;
import com.medreminder.repository.MedicineLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @Autowired
    private MedicineLogRepository logRepository;

    @GetMapping("/stats/{userId}")
    public ResponseEntity<?> getStats(@PathVariable Long userId) {
        // Find all logs for all medicines belonging to user (Requires custom query in real app, keeping simple here)
        List<MedicineLog> allLogs = logRepository.findAll(); 
        
        int total = 0;
        int taken = 0;
        int missed = 0;

        for (MedicineLog log : allLogs) {
            if (log.getMedicine().getUser().getId().equals(userId)) {
                total++;
                if (log.getStatus() == MedicineLog.Status.TAKEN) taken++;
                if (log.getStatus() == MedicineLog.Status.MISSED) missed++;
            }
        }

        int adherence = total == 0 ? 0 : (int) Math.round((taken * 100.0) / total);
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("adherencePercentage", adherence);
        stats.put("totalLogs", total);
        stats.put("taken", taken);
        stats.put("missed", missed);

        return ResponseEntity.ok(stats);
    }
}
