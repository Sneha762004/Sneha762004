package com.medreminder.repository;

import com.medreminder.model.DoctorNote;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DoctorNoteRepository extends JpaRepository<DoctorNote, Long> {
    List<DoctorNote> findByUserId(Long userId);
}
