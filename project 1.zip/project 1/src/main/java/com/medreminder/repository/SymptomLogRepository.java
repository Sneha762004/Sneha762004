package com.medreminder.repository;

import com.medreminder.model.SymptomLog;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SymptomLogRepository extends JpaRepository<SymptomLog, Long> {
    List<SymptomLog> findByUserId(Long userId);
}
