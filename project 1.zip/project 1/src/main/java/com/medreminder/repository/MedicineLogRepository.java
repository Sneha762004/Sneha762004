package com.medreminder.repository;

import com.medreminder.model.MedicineLog;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface MedicineLogRepository extends JpaRepository<MedicineLog, Long> {
    List<MedicineLog> findByMedicineId(Long medicineId);
    Optional<MedicineLog> findByMedicineIdAndDate(Long medicineId, LocalDate date);
}
