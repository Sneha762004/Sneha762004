// notifications.js - Advanced Alarms, Voice Alerts, and Missed Dose Tracking

let notifiedMedicines = new Set();
let snoozedMedicines = new Map(); 

function requestNotificationPermission() {
    if (!("Notification" in window)) {
        console.log("This browser does not support desktop notification");
    } else if (Notification.permission !== "denied" && Notification.permission !== "granted") {
        Notification.requestPermission();
    }
}

// Helper to make the browser speak!
function speak(text) {
    if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.9; // Slightly slower for clarity
        utterance.pitch = 1.1;
        window.speechSynthesis.speak(utterance);
    }
}

async function checkReminders() {
    const user = getUser();
    if(!user) return;

    try {
        const res = await fetch(`/api/medicines/user/${user.id}`);
        if (!res.ok) return;
        const medicines = await res.json();
        
        // Auto-refresh the dashboard grid if the doctor added/changed medicines
        const newHash = JSON.stringify(medicines);
        if (window.currentMedicinesHash && window.currentMedicinesHash !== newHash) {
            if (typeof loadMedicines === 'function') loadMedicines();
        }
        window.currentMedicinesHash = newHash;
        
        const now = new Date();
        const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
        const todayStr = now.toISOString().split('T')[0];

        medicines.forEach(med => {
            const medTimeFormatted = med.time.substring(0, 5); 
            const uniqueId = `${med.id}-${todayStr}-${medTimeFormatted}`;
            
            // 1. Check Snoozed items
            if (snoozedMedicines.has(uniqueId)) {
                if (now.getTime() >= snoozedMedicines.get(uniqueId)) {
                    snoozedMedicines.delete(uniqueId);
                    triggerNotification(med, uniqueId, true, false);
                }
                return; 
            }

            // 2. Normal Time Check & Late Login Check
            if (todayStr >= med.startDate && todayStr <= med.endDate) {
                if (medTimeFormatted <= currentTime && !notifiedMedicines.has(uniqueId)) {
                    notifiedMedicines.add(uniqueId); // Prevent duplicate checks
                    
                    fetch(`/api/logs/medicine/${med.id}`)
                        .then(res => res.json())
                        .then(logs => {
                            const takenToday = logs.some(l => l.date === todayStr && l.status === 'TAKEN');
                            if (!takenToday) {
                                // Trigger warning if it's past the hour
                                let medHour = parseInt(medTimeFormatted.substring(0, 2));
                                let currentHour = now.getHours();
                                let isMissedWarning = currentHour > medHour;
                                
                                triggerNotification(med, uniqueId, false, isMissedWarning);
                            }
                        })
                        .catch(err => console.error(err));
                }
            }
        });

    } catch (err) {
        console.error("Reminder check failed", err);
    }
}

function triggerNotification(medicine, uniqueId, isSnooze, isMissedWarning) {
    const now = new Date();
    const timeString = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});

    let title = "⏰ Medicine Reminder!";
    let voiceText = `Ring ring! Ring ring! Hello, it is now ${timeString}. You need to take your medicine right now. Please take ${medicine.dosage} of ${medicine.name}.`;
    
    if (isSnooze) {
        title = "⏰ SNOOZE ALERT: Medicine Time!";
        voiceText = `Ring ring! Ring ring! Your snooze is over. It is ${timeString}. Please take ${medicine.name} right now.`;
    }
    
    if (isMissedWarning) {
        title = "🚨 WARNING: Missed Dosage!";
        voiceText = `Warning! It is ${timeString} and it looks like you missed your dosage of ${medicine.name}. Please check your dashboard immediately.`;
    }

    const bodyText = `Medicine Details:\nName: ${medicine.name}\nDosage: ${medicine.dosage}\nInstructions: ${medicine.instructions || 'N/A'}`;

    if (Notification.permission === "granted") {
        const notification = new Notification(title, {
            body: bodyText,
            icon: '/favicon.ico',
            requireInteraction: true
        });
        
        notification.onclick = function() {
            window.focus();
            window.location.href = '/dashboard.html';
        };
    }

    // Always show on-screen modal if the user is actively on the page
    if (!isMissedWarning) {
        showAlarmModal(medicine, uniqueId, title, voiceText, isSnooze);
    } else {
        speak(voiceText);
        alert(`${title}\n\n${bodyText}`);
    }
}

function showAlarmModal(medicine, uniqueId, title, voiceText, isSnooze) {
    if (document.getElementById('alarmModal_' + uniqueId)) return; // Already showing

    if (!document.getElementById('alarmModalStyles')) {
        const style = document.createElement('style');
        style.id = 'alarmModalStyles';
        style.innerHTML = `
            @keyframes alarmPulse {
                0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7); }
                70% { transform: scale(1.05); box-shadow: 0 0 0 20px rgba(239, 68, 68, 0); }
                100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
            }
        `;
        document.head.appendChild(style);
    }

    const modal = document.createElement('div');
    modal.id = 'alarmModal_' + uniqueId;
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100vw';
    modal.style.height = '100vh';
    modal.style.backgroundColor = 'rgba(0,0,0,0.85)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '99999';

    const card = document.createElement('div');
    card.className = 'card glass';
    card.style.textAlign = 'center';
    card.style.padding = '3rem';
    card.style.maxWidth = '400px';
    card.style.animation = 'alarmPulse 2s infinite';
    card.style.border = '2px solid #EF4444';

    card.innerHTML = `
        <h1 style="color: #EF4444; font-size: 4rem; margin-bottom: 1rem;">⏰</h1>
        <h2 style="margin-bottom: 1rem; color: #EF4444;">${title}</h2>
        <h3 style="margin-bottom: 0.5rem; font-size: 1.5rem;">${medicine.name}</h3>
        <p style="font-size: 1.2rem; margin-bottom: 0.5rem;">Dosage: <strong>${medicine.dosage}</strong></p>
        <p style="margin-bottom: 2rem; color: var(--text-secondary);">Instructions: ${medicine.instructions || 'N/A'}</p>
        <div style="display: flex; gap: 1rem; justify-content: center;">
            <button id="btnTake_${uniqueId}" class="btn" style="background: #10B981; color: white; border: none; padding: 0.8rem 1.5rem;">✅ Mark Taken</button>
            <button id="btnSnooze_${uniqueId}" class="btn" style="background: #6B7280; color: white; border: none; padding: 0.8rem 1.5rem;">💤 Snooze 5m</button>
        </div>
    `;

    modal.appendChild(card);
    document.body.appendChild(modal);

    // Audio Playback Logic - Strictly Songs without Voice Features
    let audioToPlay = null;
    let ytIframe = document.createElement('iframe');
    ytIframe.width = '0';
    ytIframe.height = '0';
    ytIframe.frameBorder = '0';
    ytIframe.allow = 'autoplay';
    
    if (isSnooze) {
        // Snooze alarm: Varaha Roopam
        ytIframe.src = 'https://www.youtube.com/embed?autoplay=1&loop=1&listType=search&list=Varaha+Roopam+Kantara';
    } else {
        // Normal alarm: Singara Siriye
        ytIframe.src = 'https://www.youtube.com/embed/A2w7V20G6Dk?autoplay=1&loop=1&playlist=A2w7V20G6Dk';
    }
    
    modal.appendChild(ytIframe);
    
    // Add AI Voice Warning
    speak(voiceText);
    
    audioToPlay = {
        pause: function() {
            ytIframe.src = '';
        }
    };

    // Button Listeners
    document.getElementById('btnTake_' + uniqueId).onclick = () => {
        if (audioToPlay) audioToPlay.pause();
        window.speechSynthesis.cancel();
        document.body.removeChild(modal);
        if(typeof markTaken === 'function') {
            // Try to find the specific button in DOM to update its state
            let btnElements = document.querySelectorAll('button');
            let medBtn = Array.from(btnElements).find(b => b.textContent.includes('Mark Taken') && b.getAttribute('onclick')?.includes(medicine.id));
            markTaken(medicine.id, medBtn);
        }
    };

    document.getElementById('btnSnooze_' + uniqueId).onclick = () => {
        if (audioToPlay) audioToPlay.pause();
        window.speechSynthesis.cancel();
        document.body.removeChild(modal);
        const snoozeTime = new Date().getTime() + (5 * 60000);
        snoozedMedicines.set(uniqueId, snoozeTime);
    };
}

// Check every 5 seconds for fast response
setInterval(checkReminders, 5000);

// For Testing: Trigger a popup reminder immediately
async function testPopupReminder() {
    const user = getUser();
    if (!user) return;
    try {
        const res = await fetch(`/api/medicines/user/${user.id}`);
        if (!res.ok) throw new Error("Failed to fetch medicines");
        const medicines = await res.json();
        
        if (medicines.length === 0) {
            alert("You have no scheduled medicines to test.");
            return;
        }
        
        // Use the first scheduled medicine for the test
        const medToTest = medicines[0];
        triggerNotification(medToTest, "test-id-" + medToTest.id + "-" + Date.now(), false, false);
    } catch(err) {
        console.error(err);
        alert("Error testing reminder.");
    }
}
