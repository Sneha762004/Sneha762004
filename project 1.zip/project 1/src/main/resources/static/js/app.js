// app.js - Core Logic

const API_BASE = '/api';

// Auth functions
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const res = await fetch(`${API_BASE}/users/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        if (res.ok) {
            const user = await res.json();
            localStorage.setItem('user', JSON.stringify(user));
            if (user.role === 'ADMIN') {
                window.location.href = '/admin-dashboard.html';
            } else {
                // Play AI Welcome Sound for Patient
                if ('speechSynthesis' in window) {
                    const utterance = new SpeechSynthesisUtterance(`Welcome back, ${user.username}. Loading your dashboard.`);
                    utterance.onend = () => { window.location.href = '/dashboard.html'; };
                    window.speechSynthesis.speak(utterance);
                    
                    // Fallback just in case voice gets stuck
                    setTimeout(() => { window.location.href = '/dashboard.html'; }, 3000);
                } else {
                    window.location.href = '/dashboard.html';
                }
            }
        } else {
            alert('Invalid credentials');
        }
    } catch (err) {
        console.error(err);
        alert('Server error');
    }
});

document.getElementById('registerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('regUsername').value;
    const email = document.getElementById('regEmail').value;
    const role = document.getElementById('regRole').value;
    const password = document.getElementById('regPassword').value;

    try {
        const res = await fetch(`${API_BASE}/users/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, role, password })
        });

        if (res.ok) {
            alert('Registration successful! Please login.');
            toggleAuth(); // from index.html
        } else {
            const text = await res.text();
            alert(`Registration failed: ${text}`);
        }
    } catch (err) {
        console.error(err);
        alert('Server error');
    }
});

function logout() {
    localStorage.removeItem('user');
    window.location.href = '/index.html';
}

function getUser() {
    const user = localStorage.getItem('user');
    if (!user) {
        window.location.href = '/index.html';
        return null;
    }
    return JSON.parse(user);
}

// Medicine Functions
async function loadMedicines() {
    const user = getUser();
    if(!user) return;

    try {
        const res = await fetch(`${API_BASE}/medicines/user/${user.id}`);
        const medicines = await res.json();
        
        // Fetch today's logs to check if taken
        const logsRes = await Promise.all(medicines.map(m => fetch(`${API_BASE}/logs/medicine/${m.id}`)));
        const logsData = await Promise.all(logsRes.map(r => r.json()));
        
        const todayStr = new Date().toISOString().split('T')[0];
        
        // Map medicines to their status for today
        const medsWithStatus = medicines.map((med, index) => {
            const logs = logsData[index];
            const todayLog = logs.find(l => l.date === todayStr);
            return {
                ...med,
                isTakenToday: todayLog && todayLog.status === 'TAKEN'
            };
        });

        renderMedicines(medsWithStatus);
    } catch (err) {
        console.error('Failed to load medicines', err);
    }
}

function formatTime12Hour(timeStr) {
    if (!timeStr) return '';
    let [hours, minutes] = timeStr.split(':');
    hours = parseInt(hours, 10);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    return `${hours}:${minutes} ${ampm}`;
}

function renderMedicines(medicines) {
    const grid = document.getElementById('medicineGrid');
    const actionBtns = document.getElementById('actionButtonsContainer');
    if(!grid) return;
    
    grid.innerHTML = '';
    if(medicines.length === 0) {
        grid.innerHTML = '<p>No medicines scheduled. Add one to get started!</p>';
        if (actionBtns) actionBtns.style.display = 'none';
        return;
    }
    
    if (actionBtns) actionBtns.style.display = 'flex';

    medicines.forEach(med => {
        const card = document.createElement('div');
        card.className = 'card glass'; // Added glass class for consistency
        
        // Status logic
        const takenHtml = med.isTakenToday ? 
            `<button class="btn btn-secondary" disabled style="padding: 0.5rem; font-size: 0.8rem; opacity: 0.7;">✅ Taken Today</button>` :
            `<button class="btn btn-secondary" onclick="markTaken(${med.id}, this)" style="padding: 0.5rem; font-size: 0.8rem;">Mark Taken</button>`;

        card.innerHTML = `
            <div class="card-title">${med.name}</div>
            <div class="card-details">
                <p><strong>Category:</strong> ${med.category || 'N/A'}</p>
                <p><strong>Instructions:</strong> <span class="badge badge-pending">${med.instructions || 'N/A'}</span></p>
                <p><strong>Dosage:</strong> ${med.dosage}</p>
                <p><strong>Stock Left:</strong> ${med.stock !== undefined ? med.stock : 'N/A'} units</p>
                <p><strong>Time:</strong> <span class="time-display">${formatTime12Hour(med.time)}</span></p>
                <p><strong>Duration:</strong> ${med.startDate} to ${med.endDate}</p>
            </div>
            <div class="card-actions">
                ${takenHtml}
                <button class="btn btn-danger" onclick="deleteMedicine(${med.id})" style="padding: 0.5rem; font-size: 0.8rem;">Delete</button>
            </div>
        `;
        grid.appendChild(card);
    });
}

async function markTaken(medId, btnElement) {
    try {
        const res = await fetch(`${API_BASE}/logs/${medId}/mark?status=TAKEN`, { method: 'POST' });
        if(res.ok) {
            // Update button visually without reloading
            if (btnElement) {
                btnElement.disabled = true;
                btnElement.innerHTML = '✅ Taken Today';
                btnElement.style.opacity = '0.7';
                btnElement.onclick = null;
            }
            // Update the Analytics UI seamlessly
            updateAnalyticsUI();
        }
    } catch (err) {
        console.error(err);
    }
}

async function updateAnalyticsUI() {
    const user = getUser();
    if(!user) return;
    try {
        const res = await fetch(`/api/dashboard/stats/${user.id}`);
        if(res.ok) {
            const stats = await res.json();
            const scoreEl = document.getElementById('adherenceScore');
            if(scoreEl) scoreEl.innerText = stats.adherencePercentage + '%';
            
            if(window.adherenceChartInstance) {
                window.adherenceChartInstance.data.datasets[0].data = [stats.taken, stats.missed];
                window.adherenceChartInstance.update(); // Smoothly redraw chart
            }
        }
    } catch (e) { console.error(e); }
}

async function deleteMedicine(id) {
    if(!confirm('Are you sure?')) return;
    try {
        const res = await fetch(`${API_BASE}/medicines/${id}`, { method: 'DELETE' });
        if(res.ok) {
            loadMedicines();
        }
    } catch (err) {
        console.error(err);
    }
}

// 🔊 Read All Medicines Feature
async function readAllMedicines() {
    const user = getUser();
    if(!user) return;
    try {
        const res = await fetch(`${API_BASE}/medicines/user/${user.id}`);
        const medicines = await res.json();
        
        if (medicines.length === 0) {
            showScheduleModal("You have no medicines scheduled for today.", "You have no medicines scheduled for today.");
            return;
        }

        let message = "Here is your medicine schedule:\n\n";
        let speechText = "Here is your medicine schedule. ";
        
        medicines.forEach(med => {
            const timeFormatted = formatTime12Hour(med.time);
            message += `💊 ${med.name} at ${timeFormatted}\n`;
            speechText += `${med.name} at ${timeFormatted}. `;
        });

        // Show a custom modal with alert message
        showScheduleModal(message, speechText);
    } catch(e) {
        console.error(e);
        alert("Failed to read medicines");
    }
}

function speakText(text) {
    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.9;
        window.speechSynthesis.speak(utterance);
    }
}

function showScheduleModal(messageText, speechText) {
    // If modal already exists, remove it
    const existingModal = document.getElementById('scheduleModal');
    if (existingModal) existingModal.remove();

    const modal = document.createElement('div');
    modal.id = 'scheduleModal';
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100vw';
    modal.style.height = '100vh';
    modal.style.backgroundColor = 'rgba(0,0,0,0.75)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '99999';

    const card = document.createElement('div');
    card.className = 'card glass';
    card.style.padding = '2.5rem';
    card.style.maxWidth = '500px';
    card.style.width = '90%';
    card.style.textAlign = 'center';
    card.style.borderTop = '5px solid #8B5CF6';
    card.style.boxShadow = '0 10px 25px rgba(0,0,0,0.5)';
    card.style.animation = 'fadeIn 0.3s ease-out forwards';

    // Add keyframes if not exists
    if (!document.getElementById('fadeInStyle')) {
        const style = document.createElement('style');
        style.id = 'fadeInStyle';
        style.innerHTML = `
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(-20px); }
                to { opacity: 1; transform: translateY(0); }
            }
        `;
        document.head.appendChild(style);
    }

    const title = document.createElement('h2');
    title.innerText = '🔊 Medicine Schedule Alert';
    title.style.marginBottom = '1.5rem';
    title.style.color = '#8B5CF6';
    title.style.fontSize = '1.8rem';
    
    const pre = document.createElement('div');
    pre.innerText = messageText;
    pre.style.textAlign = 'left';
    pre.style.whiteSpace = 'pre-wrap';
    pre.style.fontFamily = 'Inter, sans-serif';
    pre.style.fontSize = '1.2rem';
    pre.style.lineHeight = '1.8';
    pre.style.marginBottom = '2.5rem';
    pre.style.background = 'rgba(255,255,255,0.05)';
    pre.style.padding = '1.5rem';
    pre.style.borderRadius = '12px';
    pre.style.border = '1px solid rgba(255,255,255,0.1)';

    const btnContainer = document.createElement('div');
    btnContainer.style.display = 'flex';
    btnContainer.style.justifyContent = 'center';
    btnContainer.style.gap = '1rem';

    const closeBtn = document.createElement('button');
    closeBtn.className = 'btn';
    closeBtn.innerText = 'Close';
    closeBtn.style.background = '#8B5CF6';
    closeBtn.style.color = 'white';
    closeBtn.style.padding = '0.8rem 2rem';
    closeBtn.style.fontSize = '1.1rem';
    closeBtn.onclick = () => {
        window.speechSynthesis.cancel();
        document.body.removeChild(modal);
    };

    const stopAudioBtn = document.createElement('button');
    stopAudioBtn.className = 'btn';
    stopAudioBtn.innerText = '🔇 Stop Audio';
    stopAudioBtn.style.background = '#EF4444';
    stopAudioBtn.style.color = 'white';
    stopAudioBtn.style.padding = '0.8rem 2rem';
    stopAudioBtn.style.fontSize = '1.1rem';
    stopAudioBtn.onclick = () => {
        window.speechSynthesis.cancel();
    };

    btnContainer.appendChild(stopAudioBtn);
    btnContainer.appendChild(closeBtn);

    card.appendChild(title);
    card.appendChild(pre);
    card.appendChild(btnContainer);
    modal.appendChild(card);
    document.body.appendChild(modal);

    speakText(speechText);
}

