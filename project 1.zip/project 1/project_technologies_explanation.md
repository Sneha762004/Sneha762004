# 🚀 Project Technologies & Architecture Guide

This document is your ultimate cheat sheet for explaining your **Medicine Reminder & Tracker** project. If an interviewer or professor asks how you built it, use this guide!

---

## 🛠️ The Technology Stack

You have built a **Full-Stack Web Application**. This means you built both the server-side logic (Backend) and the user interface (Frontend).

### 1. Backend (The Brains & Server)
*   **Java 17**: The core programming language used for backend logic. It is robust, secure, and industry-standard.
*   **Spring Boot (v3.x)**: The Java framework used to create the server. It makes setting up REST APIs extremely fast and handles all the heavy lifting (like embedding a Tomcat server so you don't need to install one separately).
*   **Spring Data JPA / Hibernate**: This is your ORM (Object-Relational Mapping) tool. It translates your Java Classes (like `Medicine.java` and `User.java`) directly into MySQL database tables automatically. This is why you didn't have to write raw SQL `CREATE TABLE` queries!

### 2. Database (The Storage)
*   **MySQL**: A powerful relational database. It securely stores your Users, Medicines, Doctor Notes, and Adherence Logs.
*   **application.properties**: This is where Spring Boot connects to MySQL using your credentials (`root` / `Mumma@25`).

### 3. Frontend (The User Interface)
*   **HTML5**: Provides the structure of the web pages (`dashboard.html`, `index.html`).
*   **CSS3 (Vanilla)**: Handles the beautiful styling. You implemented **Glassmorphism** (frosted glass effects using `backdrop-filter: blur`) and a dynamic **Dark Mode** using CSS Variables (`--primary-color`, etc.).
*   **JavaScript (Vanilla JS/ES6)**: Handles all the dynamic logic on the browser side without needing a heavy framework like React. It uses `fetch()` to talk to your Java API.

### 4. Advanced Frontend APIs (The "Wow" Factors)
*   **Chart.js**: An open-source JavaScript library used on the dashboard to draw the dynamic, animated Doughnut chart for the Adherence Percentage.
*   **Web Speech API (`window.speechSynthesis`)**: A native browser API that allows the browser to convert text into spoken audio (the AI Voice greeting and alarms).
*   **MediaRecorder API**: Used in the "Add Medicine" page to access the user's microphone, record custom audio, and save it as a Blob.
*   **Local Storage (`localStorage`)**: Used to keep the user logged in, remember Dark Mode preferences, and securely store the custom Voice Alarms locally.

---

## 📖 Line-by-Line Architecture Flow

Here is a simple explanation of how the code flows when a specific action happens. Explain this to show you understand how the pieces connect!

### Flow 1: How the AI Reminder Alarm Works
1.  **The Trigger (`notifications.js`)**: Every 30 seconds, `setInterval(checkReminders, 30000)` runs.
2.  **The API Call (`app.js`)**: It uses `fetch('/api/medicines/user/{id}')` to ask the Java backend for all medicines.
3.  **The Backend (`MedicineController.java`)**: Java receives the request, asks MySQL for the data via `MedicineRepository`, and sends it back as JSON.
4.  **The Time Check (`notifications.js`)**: The JavaScript compares the medicine's scheduled time with your computer's exact current time.
5.  **The Alarm (`notifications.js`)**: If the times match, it checks `localStorage` for a custom voice recording. If one exists, it plays it. If not, it uses `window.speechSynthesis.speak()` to read the time and medicine name out loud, and displays a Popup Alert.

### Flow 2: How "Mark Taken" Updates the Chart Instantly
1.  **The Click (`app.js`)**: You click "Mark Taken". The function `markTaken(medId, btnElement)` is called.
2.  **The Backend Save (`LogController.java`)**: A POST request is sent to Java to save a new `MedicineLog` into the MySQL database with the status `TAKEN`.
3.  **The UI Update (`app.js`)**: Instead of reloading the whole page, JavaScript instantly changes the button to "✅ Taken Today" (`btnElement.innerHTML = ...`).
4.  **The Math (`DashboardController.java`)**: JavaScript calls `/api/dashboard/stats/`. Java grabs all logs, calculates `(taken / total) * 100`, and returns the Adherence Percentage.
5.  **The Animation (`dashboard.html`)**: JavaScript grabs the global `window.adherenceChartInstance`, updates the data array `[taken, missed]`, and calls `.update()`. Chart.js smoothly animates the Doughnut chart to the new percentage!

### Flow 3: How the Admin/Patient Separation Works
1.  **Registration (`UserController.java`)**: When a user registers, the dropdown sends a `role` of either `"ADMIN"` or `"PATIENT"`. This is saved in MySQL.
2.  **Login Routing (`app.js`)**: When logging in, Java checks the credentials. If valid, JavaScript looks at `user.role`. If it's `"ADMIN"`, you are sent to `admin-dashboard.html`. Otherwise, you go to `dashboard.html`.
3.  **Security (`add-medicine.html`)**: At the very top of the `<script>` tag, there is a check: `if(user.role !== 'ADMIN')`. If a patient tries to cheat and type the URL to add a medicine manually, this script catches them, alerts "Access Denied", and kicks them back to their dashboard!
